import pygame, sys
from pygame.locals import *
import time
pygame.init()

#This is a simple 'game' where you move two cats around

def main():
    #check if tie is moving
    moving=False

    #basic colors
    WHITE = (255, 255, 255)
    BLACK = (0, 0, 0)
    RED = (255, 0, 0)
    GREEN = (0, 255, 0)
    BLUE = (0, 0, 255)
    PINK = (255, 0, 255)
    Yellow = (166, 100, 200)
    Brown = (100, 25, 60)

    #starting tie location and destination
    catx = 440
    caty = 60
    destinationcatx=10
    destinationcaty=60

    nyancatx = 10
    nyancaty = 60
    destinationnyanx = 10
    destinationnyany = 60


    #tie image
    CatImg = pygame.image.load('cat.png')
    NyancatImg = pygame.image.load('nyancat.png')

    #exit button
    exit_button=pygame.image.load('exit_unclicked.png')
    exit_clicked=pygame.image.load('exit_clicked.png')
    exitButton=False#exit hasn't been clicked yet

    #save buttom
    save_unclicked=pygame.image.load('save_unclicked.png')
    save_clicked=pygame.image.load('save_clicked.png')

    #load button
    load_button=pygame.image.load('load_unclicked.png')
    load_clicked=pygame.image.load('load_clicked.png')

    #audio
    soundObj = pygame.mixer.Sound('Catsound.wav')

    #calculates destination to nearest 10, otherwise the tie goes crazy trying to get to location because it never reaches right number
    def destination(x,base=10):
        return int(base*round(float(x)/base))

    #saving to position file
    def saveIt(w, x, y, z):
        #print(destinationx, destinationy)
        saveit = open('position.txt', 'w')
        saveit.write(str(w) + ',' + str(x) + ',' + str(y) + ',' + str(z))
        saveit.close()

    def loadCat():
        filereader = open('position.txt', 'r')
        line = filereader.readline()
        nums = line.split(',')
        w = int(nums[0])
        x = int(nums[1])
        filereader.close()
        destinationcatx = int(w)
        destinationcaty = int(x)
        return (destinationcatx, destinationcaty)

    def loadNyan():
        filereader = open('position.txt', 'r')
        line = filereader.readline()
        nums = line.split(',')
        y = int(nums[2])
        z = int(nums[3])
        filereader.close()
        destinationnyanx = int(y)
        destinationnyany = int(z)
        return (destinationnyanx, destinationnyany)



    while True:# the main game loop
        #surface
        DISPLAYSURF = pygame.display.set_mode((500, 400))
        DISPLAYSURF.fill(WHITE)
        pygame.display.set_caption('Flying Cat')

        #draw images
        DISPLAYSURF.blit(CatImg, (catx, caty))  # paste tie at current x,y
        DISPLAYSURF.blit(NyancatImg, (nyancatx, nyancaty))
        DISPLAYSURF.blit(exit_button, (10, 10))
        DISPLAYSURF.blit(save_unclicked,(390,10))
        DISPLAYSURF.blit(load_button, (200,10))

        if exitButton:#if exit has been clicked, this way the image changes below, then on update exits after .1 sec
            pygame.time.wait(100)
            pygame.quit()
            sys.exit()
        if moving:#this checks to see if tie is currently moving, false to start, true after button is clicked
            if catx > destinationcatx: #changes tie location to destination x,y
                catx -= 10
            elif catx < destinationcatx:
                catx += 10
            if caty > destinationcaty:
                caty -= 10
            elif caty < destinationcaty:
                caty += 10

        FPS = 30 # frames per second setting
        fpsClock = pygame.time.Clock()

        for event in pygame.event.get():#event handling
            if event.type == QUIT or (event.type == KEYUP and event.key == K_ESCAPE):
                pygame.quit()
                sys.exit()

            elif event.type == MOUSEBUTTONDOWN: #if player clicks, changes tie to moving, and gets destination to nearest 10
                mousex, mousey = event.pos

                #check if exit clicked
                if mousex<=150 and mousey<=90:
                    if mousex<=100 and mousey<=50 and mousey>=10 and mousex>=10:
                        exitButton=True
                        DISPLAYSURF.blit(exit_clicked, (10, 10))
                        break
                    soundObj.play()
                    destinationcatx=10
                    destinationcaty=60

                #check if save clicked
                elif mousex>=340 and mousey<=90:
                    #SAVE CLICKED
                    if mousex>=390 and mousex<=490 and mousey<=50 and mousey>=10:
                        DISPLAYSURF.blit(save_clicked,(390,10))
                        saveIt(destinationcatx, destinationcaty, destinationnyanx, destinationnyany)
                        break
                    soundObj.play()
                    destinationcatx=390
                    destinationcaty=60
                #check if load clicked
                elif mousex<=300 and mousey<=90:
                    if mousex >= 200 and mousex <= 300 and mousey <= 50 and mousey >= 10:
                        DISPLAYSURF.blit(load_clicked, (200, 10))
                        loadCat()
                        loadNyan()
                        #destinationcatx, destinationcaty = loadCat()
                        #destinationnyanx, destinationnyany = loadNyan()
                        catx = int(destinationcatx)
                        caty = int(destinationcaty)
                        nyancatx = int(destinationnyanx)
                        nyancaty = int(destinationnyany)

                else:
                    soundObj.play()
                    #moving = True
                    destinationcatx=destination(mousex-25) #subtract 50 to get center

                    #all below is checking edges, if hits edge it goes as far as possible
                    if destinationcatx<=10:
                        destinationcatx=0
                    elif destinationcatx>=440:
                        destinationcatx=440
                    destinationcaty=destination(mousey-25)
                    if destinationcaty>=360:
                        destinationcaty=360
                    elif destinationcaty<=50:
                        destinationcaty=60

            elif event.type == pygame.KEYDOWN:
                destinationcatx = catx
                destinationcaty = caty

                destinationnyanx = nyancatx
                destinationnyany = nyancaty
                if event.key == pygame.K_UP:
                    if destinationcaty <= 60:
                        caty = 60
                    else:
                        caty = caty - 10
                        soundObj.play()
                elif event.key == pygame.K_LEFT:
                    if destinationcatx <= 10:
                        catx = 0
                    else:
                        catx = catx - 10
                        soundObj.play()
                elif event.key == pygame.K_RIGHT:
                    if destinationcatx >= 440:
                        catx = 440
                    else:
                        catx = catx + 10
                        soundObj.play()
                elif event.key == pygame.K_DOWN:
                    if destinationcaty >= 360:
                        caty = 360
                    else:
                        caty = caty + 10
                        soundObj.play()

                elif event.key == pygame.K_w:
                    if destinationnyany <= 60:
                        nyancaty = 60
                    else:
                        nyancaty = nyancaty - 10
                        soundObj.play()
                elif event.key == pygame.K_a:
                    if destinationnyanx <= 10:
                        nyancatx = 0
                    else:
                        nyancatx = nyancatx - 10
                        soundObj.play()
                elif event.key == pygame.K_d:
                    if destinationnyanx >= 440:
                        nyancatx = 440
                    else:
                        nyancatx = nyancatx + 10
                        soundObj.play()
                elif event.key == pygame.K_s:
                    if destinationnyany >= 360:
                        nyancaty = 360
                    else:
                        nyancaty = nyancaty + 10
                        soundObj.play()





            elif event.type == pygame.KEYUP:
                if event.key == pygame.K_w or event.key == pygame.K_a or event.key == K_d or event.key == K_s:
                    caty = caty + 0
                    catx = catx + 0
                    destinationcatx = catx
                    destinationcaty = caty




        #print(mousex,mousey) this was for debugging

        # run the game loop
        pygame.display.update()
        fpsClock.tick(FPS)



if __name__ == '__main__':
    main()