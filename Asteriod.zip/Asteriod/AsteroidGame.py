import pygame
import sys
import time
from pygame.locals import *
import random

background = (0, 0, 0)
entity_color = (255, 255, 255)

global lives
global points
lives = 3
points = 0
bullet = []
listAsteroid=[]
leveltime=50
creationTime=leveltime

pygame.init()

window_width = 400
window_height = 500
screen = pygame.display.set_mode((window_width, window_height))

WHITE = (255, 255, 255)
fontObj = pygame.font.Font('freesansbold.ttf', 12)

ShipImg = pygame.image.load('ship.png')
Shiplive1Img = pygame.image.load('shiplives.png')
Shiplive2Img = pygame.image.load('shiplives.png')
Shiplive3Img = pygame.image.load('shiplives.png')
bulletImg = pygame.image.load("bullet.png")
LargeImg = pygame.image.load('largerock.png')
shipx = 175
shipy = 450

class Entity(pygame.sprite.Sprite):
    """Inherited by any object in the game."""

    def __init__(self, shipx, shipy, width, height):
        pygame.sprite.Sprite.__init__(self)

        self.x = shipx
        self.y = shipy
        self.width = 50
        self.height = 50
        self.rect = pygame.Rect(self.x, self.y, self.width, self.height)


class Spaceship(Entity):
    def __init__(self, x, y, width, height):
        super(Spaceship, self).__init__(x, y, width, height)

        self.image = ShipImg


class Player(Spaceship):

    def __init__(self, x, y, width, height):
        super(Player, self).__init__(x, y, width, height)
        #self.y_change = 0
        self.x_change = 0
        #self.y_dist = 5
        self.x_dist = 5

    def MoveKeyRight(self, key):
        """Responds to a key-down event and moves accordingly"""
        #if (key == pygame.K_UP):
            #self.y_change += -self.y_dist
        #elif (key == pygame.K_DOWN):
            #self.y_change += self.y_dist
        if (key == pygame.K_LEFT):
            self.x_change += -self.x_dist
        elif (key == pygame.K_RIGHT):
            self.x_change += self.x_dist

    def MoveKeyLeft(self, key):
        """Responds to a key-up event and stops movement accordingly"""
        #if (key == pygame.K_UP):
            #self.y_change += self.y_dist
        #elif (key == pygame.K_DOWN):
            #self.y_change += -self.y_dist
        if (key == pygame.K_LEFT):
            self.x_change += self.x_dist
        elif (key == pygame.K_RIGHT):
            self.x_change += -self.x_dist

    def update(self):
        """
        Moves the paddle while ensuring it stays in bounds
        """
        # Moves it relative to its current location.
        #self.rect.move_ip(0, self.y_change)
        self.rect.move_ip(self.x_change, 0 )

        # If the paddle moves off the screen, put it back on.
        if self.rect.x < 10:
            self.rect.x = 10
        elif self.rect.x > 410 - self.width:
            self.rect.x = 410 - self.width

class Bullet(pygame.sprite.Sprite):
    """ This class represents the bullet . """

    def __init__(self):
        # Call the parent class (Sprite) constructor
        super().__init__()

        self.image = bulletImg

        self.rect = self.image.get_rect()

    def update(self):
        """ Move the bullet. """
        self.rect.y -= 15


class Block(pygame.sprite.Sprite):
    """ This class represents the block. """

    def __init__(self):
        # Call the parent class (Sprite) constructor
        super().__init__()

        self.image = LargeImg

        self.rect = self.image.get_rect()

    def update(self):
        """ Move the block. """
        self.rect.y += 1



First = Block()
player = Player(shipx, shipy, 20, 50)

all_sprites_list = pygame.sprite.Group()
all_sprites_list.add(player)
all_sprites_list.add(First)

clock = pygame.time.Clock()

block_list = pygame.sprite.Group()

listAsteroid.append(First)
block_list.add(First)
all_sprites_list.add(First)

while True:
    #textSurfaceObj1 = fontObj.render('Lives x ' + str(lives), True, WHITE)
    textSurfaceObj2 = fontObj.render(str(points), True, WHITE)
    #textRectObj1 = textSurfaceObj1.get_rect()
    textRectObj2 = textSurfaceObj2.get_rect()
    #textRectObj1 = (25, 25)
    textRectObj2.center = (370, 10)
    screen.fill(background)
    pygame.display.set_caption('Asteroid Game')
    #screen.blit(textSurfaceObj1, textRectObj1)
    screen.blit(textSurfaceObj2, textRectObj2)
    #screen.blit(ShipImg, (shipx, shipy))
    bullet_list = pygame.sprite.Group()
    #screen.blit(Shiplive1Img, (10, 5))
    #screen.blit(Shiplive2Img, (30, 5))
    #screen.blit(Shiplive3Img, (50, 5))

    if creationTime<=0:#This creates asteroids after set amount of time
        x=Block()
        x.rect.x = random.randrange(window_width - 30)
        x.rect.y = (0)
        listAsteroid.append(x)
        block_list.add(x)
        all_sprites_list.add(x)
        leveltime-=1 #each time an asteroid is formed we make it shorter until next is made
        creationTime=leveltime
        print(len(listAsteroid))


    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            player.MoveKeyRight(event.key)
        elif event.type == pygame.KEYUP:
            player.MoveKeyLeft(event.key)

        if event.type == KEYDOWN:
            if event.key == K_SPACE:
                bullet = Bullet()
                # Set the bullet so it is where the player is
                bullet.rect.x = player.rect.x + 13
                bullet.rect.y = player.rect.y - 8
                # Add the bullet to the lists
                all_sprites_list.add(bullet)
                bullet_list.add(bullet)

    for bullet in bullet_list:
        bullet_hit_list = pygame.sprite.spritecollide(bullet, block_list, True)

        for block in bullet_hit_list:
            bullet_list.remove(bullet)
            all_sprites_list.remove(bullet)
            points += 100

        # Remove the bullet if it flies up off the screen
        if bullet.rect.y < -10:
            bullet_list.remove(bullet)
            all_sprites_list.remove(bullet)

    for block in block_list:
        if block.rect.colliderect(player.rect):
            #liveimg = 'Shiplive' + livenum + 'Img'
            points -= 100
            #livenum = int(livenum)- 1
            block_list.remove(block)
            block.remove(all_sprites_list)
            lives -= 1
            print(lives)

    if lives == 0:
        break
    else:
        pass



    for ent in all_sprites_list:
        ent.update()

    all_sprites_list.draw(screen)
    creationTime -= 1
    pygame.display.update()

    clock.tick(60)

